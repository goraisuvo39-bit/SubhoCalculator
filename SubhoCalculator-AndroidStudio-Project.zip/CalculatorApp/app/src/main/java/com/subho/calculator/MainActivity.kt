package com.subho.calculator

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.media.MediaPlayer
import java.util.Locale
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var display: TextView
    private var expression = ""
    private var soundIndex = 0
    private var player: MediaPlayer? = null
    private val soundFiles = arrayOf("sound1.mp3", "sound2.mp3", "sound3.mp3")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 18, 30)
        window.navigationBarColor = Color.rgb(15, 18, 30)
        window.decorView.systemUiVisibility = 0
        buildUi()
    }

    private fun playNextSound() {
        try {
            player?.release()
            val afd = assets.openFd(soundFiles[soundIndex])
            player = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                setOnCompletionListener { it.release(); if (player === it) player = null }
                prepare()
                start()
            }
            afd.close()
            soundIndex = (soundIndex + 1) % soundFiles.size
        } catch (_: Exception) { }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18); setBackgroundColor(Color.rgb(15,18,30)) }
        val heading = TextView(this).apply { text = "SUBHO CALCULATOR"; setTextColor(Color.WHITE); textSize = 17f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 10, 0, 16) }
        root.addView(heading, LinearLayout.LayoutParams(-1, 48))
        display = TextView(this).apply { text = "0"; setTextColor(Color.WHITE); textSize = 36f; gravity = Gravity.END or Gravity.CENTER_VERTICAL; setPadding(8, 12, 8, 12); maxLines = 2 }
        root.addView(display, LinearLayout.LayoutParams(-1, 0, 1.2f))
        val keys = arrayOf(
            arrayOf("sin", "cos", "tan", "log"),
            arrayOf("√", "x²", "π", "%"),
            arrayOf("AC", "⌫", "÷", "×"),
            arrayOf("7", "8", "9", "−"),
            arrayOf("4", "5", "6", "+"),
            arrayOf("1", "2", "3", "="),
            arrayOf("0", ".", "(", ")")
        )
        val grid = GridLayout(this).apply { columnCount = 4; rowCount = keys.size; useDefaultMargins = true }
        keys.forEach { row -> row.forEach { key ->
            val b = Button(this).apply {
                text = key; textSize = if (key.length > 2) 14f else 19f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(when(key) { "=" -> Color.rgb(35,155,115); "AC", "⌫" -> Color.rgb(190,75,85); "+", "−", "×", "÷", "%" -> Color.rgb(65,83,130); else -> Color.rgb(38,44,62) }))
                setOnClickListener { playNextSound(); handleKey(key) }
            }
            val lp = GridLayout.LayoutParams().apply { width = 0; height = 0; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(4,4,4,4) }
            grid.addView(b, lp)
        } } }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 5f))
        setContentView(root)
    }

    private fun handleKey(k: String) {
        when (k) {
            "AC" -> expression = ""
            "⌫" -> if (expression.isNotEmpty()) expression = expression.dropLast(1)
            "=" -> try { expression = format(evaluate(expression)) } catch (_: Exception) { display.text = "Error"; return }
            "sin", "cos", "tan", "log", "√" -> expression += "$k("
            "x²" -> expression += "^2"
            "π" -> expression += "pi"
            "×" -> expression += "*"
            "÷" -> expression += "/"
            "−" -> expression += "-"
            else -> expression += k
        }
        display.text = if (expression.isEmpty()) "0" else expression
    }

    private fun format(v: Double): String = if (v.isFinite()) String.format(Locale.US, "%.10f", v).trimEnd('0').trimEnd('.') else "Error"

    // Recursive-descent expression parser with scientific functions and operator precedence.
    private fun evaluate(src: String): Double {
        val s = src.replace("×", "*").replace("÷", "/").replace("−", "-").replace("pi", Math.PI.toString()).replace(" ", "")
        var p = 0
        fun eat(c: Char): Boolean { if (p < s.length && s[p] == c) { p++; return true }; return false }
        lateinit var expr: () -> Double
        lateinit var term: () -> Double
        lateinit var power: () -> Double
        lateinit var factor: () -> Double
        factor = {
            when {
                eat('+') -> factor()
                eat('-') -> -factor()
                eat('(') -> expr().also { if (!eat(')')) error("paren") }
                else -> {
                    val start = p
                    while (p < s.length && (s[p].isLetter() || s[p] == '√')) p++
                    if (p > start) {
                        val fn = s.substring(start, p)
                        if (fn == "pi") Math.PI else {
                            if (!eat('(')) error("function")
                            val x = expr(); if (!eat(')')) error("paren")
                            when(fn) { "sin" -> sin(Math.toRadians(x)); "cos" -> cos(Math.toRadians(x)); "tan" -> tan(Math.toRadians(x)); "log" -> log10(x); "√", "sqrt" -> sqrt(x); else -> error("function") }
                        }
                    } else {
                        val st = p
                        while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
                        if (st == p) error("number")
                        s.substring(st,p).toDouble()
                    }
                }
            }
        }
        power = { var x = factor(); if (eat('^')) x = x.pow(power()); x }
        term = { var x = power(); while (true) { if (eat('*')) x *= power() else if (eat('/')) x /= power() else if (eat('%')) x %= power() else break }; x }
        expr = { var x = term(); while (true) { if (eat('+')) x += term() else if (eat('-')) x -= term() else break }; x }
        val result = expr(); if (p != s.length) error("tail"); result
    }

    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
